calculator = lambda x, y, z: x + y if z == '+' else x - y if z == '-' else x * y if z =='*' else "You can't divide by ZERO" if z == '/' and y == 0 else x // y
input = [x for x in input().split(' ')]
print(calculator(int(input[0]), int(input[1]), input[2]))