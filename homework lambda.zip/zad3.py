string_multiplyer = lambda x, y: x * y
x = str(input())
y = int(input())
print(string_multiplyer(x, y))