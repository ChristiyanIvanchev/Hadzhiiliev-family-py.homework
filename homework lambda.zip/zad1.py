def grades_func(x):
    if 2 >= average_success < 3:
        return 'Fail'
    elif 3 >= average_success < 3.50:
        return 'Poor'
    elif 3.50 >= average_success < 4.50:
        return 'Good'
    elif 4.50 >= average_success < 5.50:
        return 'Very Good'
    elif 5.50 >= average_success <= 6:
        return 'Excellent'

average_success = float(input())
print(grades_func(average_success))